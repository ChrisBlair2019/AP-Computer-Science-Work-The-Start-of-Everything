/**
 * This is a class that tests the Deck class.
 */
public class DeckTester {

	/**
	 * The main method in this class checks the Deck operations for consistency.
	 *	@param args is not used.
	 */
	public static void main(String[] args) {
		/* *** TO BE IMPLEMENTED IN ACTIVITY 2 *** */
	String[] ranks = {"King", "Queen","Ace","Ten"};
	String[] suits = {"Clubs","Hearts","Spades","Diamonds"};
	int[] values = 	 {10,11,13,18};
	Deck newDeck = new Deck(ranks,suits,values);
		
		System.out.println("Is it Empty?"+ " " + newDeck.isEmpty());
		System.out.println();
		System.out.println("The String version of the Deck"+ " " + newDeck.toString());
		System.out.println(newDeck.deal());
		System.out.println();
		System.out.println("What is the size?" + " " + newDeck.size());

	}
}
//Name:Chris Blair
//School:Red Bank Catholic
//Assignment:20.4 Program it
//Date:02/10/2015